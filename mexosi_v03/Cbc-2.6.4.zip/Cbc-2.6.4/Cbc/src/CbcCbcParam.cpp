/* $Id: CbcCbcParam.cpp 1173 2009-06-04 09:44:10Z forrest $ */
#include "CbcConfig.h"
#ifndef COIN_HAS_CBC
#define COIN_HAS_CBC
#endif
#include "CbcOrClpParam.cpp"

