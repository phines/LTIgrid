/* $Id: CbcCompareActual.hpp 1432 2010-02-07 19:33:53Z bjarni $ */
// Copyright (C) 2002, International Business Machines
// Corporation and others.  All Rights Reserved.
#ifndef CbcCompareActual_H
#define CbcCompareActual_H
#include "CbcNode.hpp"
#include "CbcCompareBase.hpp"
#include "CbcCompare.hpp"
#include "CbcCompareDepth.hpp"
#include "CbcCompareDefault.hpp"
#endif

