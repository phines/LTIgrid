/* $Id: CoinWarmStartVector.cpp 1191 2009-07-25 08:38:12Z forrest $ */
// Copyright (C) 2003, International Business Machines
// Corporation and others.  All Rights Reserved.
